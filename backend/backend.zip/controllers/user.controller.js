export const TestApi = (req, res) => {
  res.json({ message: "test api new successdfs" });
};
